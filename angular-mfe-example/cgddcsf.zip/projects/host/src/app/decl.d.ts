declare module 'remoteapp1/homeModule';
declare module 'remoteapp2/homeModule';
declare module 'remoteapp1/repoModule';
declare module 'remoteapp2/authModule';
declare module 'remoteapp1/imgModule';
declare module 'remoteapp1/repoManageModule';
declare module 'remoteapp2/resetModule';
declare module 'remoteapp2/emailModule';
declare module 'remoteapp1/directoryModule';
// declare module 'remoteapp2/adminModule';
// declare module 'remoteapp2/sideModule';
// declare module 'remoteapp2/userModule';
// declare module 'remoteapp2/userManageModule';
// declare module 'remoteapp2/editModule';

